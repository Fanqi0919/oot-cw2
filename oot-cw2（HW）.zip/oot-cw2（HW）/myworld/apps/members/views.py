from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
# Create your views here.
from django.template import loader
from django.urls import reverse

def index(request):
    template = loader.get_template('store.html')
    return HttpResponse(template.render())